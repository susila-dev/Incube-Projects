package com.merchant.portal.controller;

import com.merchant.portal.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
@CrossOrigin(origins = "*")
public class AnalyticsController {
    
    @Autowired
    private OrderService orderService;
    
    @GetMapping
    public Map<String, Object> getAnalytics() {
        return orderService.getAnalytics();
    }
}
