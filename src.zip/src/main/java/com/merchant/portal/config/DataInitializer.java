package com.merchant.portal.config;

import com.merchant.portal.model.Order;
import com.merchant.portal.model.OrderItem;
import com.merchant.portal.model.Product;
import com.merchant.portal.repository.OrderRepository;
import com.merchant.portal.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Component
public class DataInitializer {
    
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private OrderRepository orderRepository;
    
    private Random random = new Random();
    
    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void loadData() {
        List<Product> products = Arrays.asList(
            new Product("Wireless Mouse", "Ergonomic wireless mouse with 2.4GHz connectivity", new BigDecimal("29.99"), 150, "Electronics"),
            new Product("Mechanical Keyboard", "RGB backlit mechanical gaming keyboard", new BigDecimal("89.99"), 75, "Electronics"),
            new Product("USB-C Hub", "7-in-1 USB-C hub with HDMI and Ethernet", new BigDecimal("45.99"), 200, "Electronics"),
            new Product("Laptop Stand", "Aluminum laptop stand with adjustable height", new BigDecimal("39.99"), 120, "Accessories"),
            new Product("Webcam HD", "1080p HD webcam with built-in microphone", new BigDecimal("59.99"), 8, "Electronics"),
            new Product("Phone Case", "Protective silicone phone case", new BigDecimal("19.99"), 300, "Accessories"),
            new Product("Bluetooth Speaker", "Portable waterproof bluetooth speaker", new BigDecimal("49.99"), 6, "Electronics"),
            new Product("Screen Protector", "Tempered glass screen protector", new BigDecimal("12.99"), 250, "Accessories"),
            new Product("Power Bank", "20000mAh portable power bank", new BigDecimal("34.99"), 90, "Electronics"),
            new Product("HDMI Cable", "6ft 4K HDMI cable", new BigDecimal("14.99"), 180, "Cables")
        );
        
        productRepository.saveAll(products);
        
        List<String> customerNames = Arrays.asList("John Smith", "Sarah Johnson", "Mike Brown", "Emily Davis", "David Wilson");
        List<String> customerEmails = Arrays.asList("john@example.com", "sarah@example.com", "mike@example.com", "emily@example.com", "david@example.com");
        
        for (int i = 0; i < 15; i++) {
            int customerIndex = random.nextInt(customerNames.size());
            Order order = new Order();
            order.setOrderNumber("ORD-" + String.format("%05d", 1000 + i));
            order.setCustomerName(customerNames.get(customerIndex));
            order.setCustomerEmail(customerEmails.get(customerIndex));
            order.setStatus(getRandomStatus());
            
            int numItems = random.nextInt(3) + 1;
            BigDecimal total = BigDecimal.ZERO;
            
            for (int j = 0; j < numItems; j++) {
                Product product = products.get(random.nextInt(products.size()));
                int quantity = random.nextInt(3) + 1;
                BigDecimal itemTotal = product.getPrice().multiply(new BigDecimal(quantity));
                total = total.add(itemTotal);
                
                OrderItem item = new OrderItem(product, quantity, product.getPrice());
                order.addItem(item);
            }
            
            order.setTotalAmount(total);
            orderRepository.save(order);
        }
    }
    
    private Order.OrderStatus getRandomStatus() {
        Order.OrderStatus[] statuses = Order.OrderStatus.values();
        return statuses[random.nextInt(statuses.length)];
    }
}
